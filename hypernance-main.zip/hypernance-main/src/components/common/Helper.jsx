import { Electricicon } from "./icon";
import userImg from "../../assets/img/user-img.png";

export const tabelData = [
  {
    icon: <Electricicon />,
    name: "Electricity",
    date: "21 july",
    time: "09:00",
    amount: "+$234.87",
  },
  {
    icon: <Electricicon />,
    name: "Electricity",
    date: "21 july",
    time: "09:00",
    amount: "+$234.87",
  },
  {
    icon: <Electricicon />,
    name: "Electricity",
    date: "21 july",
    time: "09:00",
    amount: "+$234.87",
  },
  {
    icon: <Electricicon />,
    name: "T Mobile Bill",
    date: "28 july",
    time: "07:00",
    amount: "-$124.45",
  },
  {
    icon: <Electricicon />,
    name: "AT&T",
    date: "25 july",
    time: "05:00",
    amount: "+$105.77",
  },
  {
    icon: <Electricicon />,
    name: "Dominos",
    date: "29 july",
    time: "02:00",
    amount: "+$90.67",
  },
  {
    icon: <Electricicon />,
    name: "H&M",
    date: "31 july",
    time: "04:00",
    amount: "+$190.88",
  },
];
export const usersData = [
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
  {
    img: userImg,
    name: "Jordan Stlouis",
    phone: "(684) 555-0102",
    email: "lawson@example.com",
  },
];
